function showDialog(){
    alert("this is dialog");
}

export default showDialog;