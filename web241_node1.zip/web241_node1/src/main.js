import showDialog from "./dialog";
import $ from "jquery";
import "slick-carousel";
import "slick-carousel/slick/slick.scss";
import "slick-carousel/slick/slick-theme.scss";
import "lightbox2";
import "lightbox2/dist/css/lightbox.min.css";

document.querySelector(".title1").onclick = function(){
    showDialog();

}
$(document).ready(function(){
    $(".carousel").slick();

    $(".title1").css({"color":"red","font-size":"30pt"});

    $("h1").hover(function(event){
        $(this).css("color","green");
    });

    $("h1").dblclick(function(){
        $("body").append(`<p>${$(this).text()}</p>`);
    })

    $("input[name='bodyColor']").change(function(){
        $("body").css("background",$(this).val());
    })


    $("form").submit(function(event){
        event.preventDefault();
        if($("input[name='mail']").val()==""){
            $("input[name='mail']").addClass("error");
        }
        data =  $("form").serialize();
        $.post("https://jsonplaceholder.typicode.com/posts",data,function(resp){
            console.log(resp);
        })
        
    })

})


