import React from "react";
import { useState } from "react";
import "./card.scss";




function Card(props){
    const [text,setText] = useState("");
    const [dialog,showDialog] = useState(false);

    return (
        <>
            <div className="card">
                <h3>{props.title}</h3>
                <img src={props.img} alt="icon"/>
                <p>{props.text}</p>
                <button 
                    onClick={
                        ()=>{
                        setText(props.text);
                        showDialog(true);
                    }}
                    >Click Me</button>
            </div>
            <div className={dialog?"dialog":"hidden-dialog"}>
                       
                        <p>{text}</p>
                        <button 
                            onClick={()=>{
                                showDialog(false)}}>Close</button>
            </div>
        </>
    )
}

export default Card;