import React from "react";
import "./header.scss";

function Header(){

  let mainTitle = "Learning React",
      subTitle = "My first react WebSite" ; 

    return (
        <>
            <header>
                <h1>{mainTitle}</h1>
                <h2>{subTitle}</h2>
            </header>
        </>
    )
}

export default Header;