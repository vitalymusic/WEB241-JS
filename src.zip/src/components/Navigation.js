import React from "react";
import "./nav.scss";


function Navigation(){
    let navObject = [
        {
            name:"Page1",
            url:"/"
        },
        {
            name:"Page2",
            url:"/page2"
        },
        {
            name:"Page3",
            url:"/page3"
        }


    ];

    return(
        <nav>
            {navObject.map(function(item,number){
                return (
                    <a href={item.url} key={number}>{item.name}</a>
                )
            })}
        </nav>
    )
}

export default Navigation;