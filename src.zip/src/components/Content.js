import React from "react";
import "./content.scss";
import Card from "./Card";

function Content(){

//   let mainTitle = "Learning React",
//       subTitle = "My first react WebSite" ; 
        let cardsData = [
            {
                title:"BMW",
                img:"https://www.bmw.lv/content/dam/bmw/common/all-models/m-series/m8-gran-coupe/2022/navigation/bmw-m8-competition-gran-coupe-modelfinder.png",
                text:"Bayerische Motoren Werke AG, commonly abbreviated to BMW (German pronunciation: [ˌbeːʔɛmˈveː] ⓘ), is a German multinational manufacturer of luxury vehicles and motorcycles headquartered in Munich, Bavaria, Germany. The company was founded in 1916 as a manufacturer of aircraft engines, which it produced from 1917 to 1918 and again from 1933 to 1945 creating engines for aircraft that were used in the Second World War."
            },
            {
                title:"AUDI",
                img:"https://mediaservice.audi.com/media/live/50900/fly1400x601n1/gegcvc/2024.png?wid=850",
                text:"Audi automobiļu kompānijas vēsture aizsākusies 1909. gadā, 16. jūlijā, kad konstruktors Augusts Horhs reģistrēja kompānijas nosaukumu. 1932. gada 29. jūnijā uzņēmuma — Horch, Wanderer, DKW un Audi — iestājās vienotā koncernā, ko nosauca par Auto Union GmbH, tādējādi radot mūsdienās tik plaši pazīstamo emblēmu, kurā savienoti četri apļi."
            },
            {
                title:"BMW",
                img:"https://www.bmw.lv/content/dam/bmw/common/all-models/m-series/m8-gran-coupe/2022/navigation/bmw-m8-competition-gran-coupe-modelfinder.png",
                text:"Bayerische Motoren Werke AG, commonly abbreviated to BMW (German pronunciation: [ˌbeːʔɛmˈveː] ⓘ), is a German multinational manufacturer of luxury vehicles and motorcycles headquartered in Munich, Bavaria, Germany. The company was founded in 1916 as a manufacturer of aircraft engines, which it produced from 1917 to 1918 and again from 1933 to 1945 creating engines for aircraft that were used in the Second World War."
            },

        ];


    return (
        <>
            {/* props */}
            <div className="cards">
                {
                    cardsData.map(function(item,i){
                        return (
                            <Card title={item.title} img={item.img} text={item.text} key={i}></Card>
                        )
                    })
                }    
            </div>
        </>
    )
}

export default Content;